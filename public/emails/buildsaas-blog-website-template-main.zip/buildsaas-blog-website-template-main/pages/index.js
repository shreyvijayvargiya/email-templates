import React, { useMemo } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowRight, Calendar } from "lucide-react";
import Navbar from "../app/components/Navbar";
import Footer from "../app/components/Footer";
import { getAllBlogs } from "../lib/api/blog";
import SubscribeCard from "../app/components/SubscribeCard";

const SAMPLE_POSTS = [
	{
		id: "sample-1",
		slug: "welcome-to-your-new-blog",
		title: "Welcome to your new blog",
		author: "Editor",
		createdAt: new Date(),
		bannerImage:
			"https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=60",
		excerpt:
			"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
	},
	{
		id: "sample-2",
		slug: "how-to-write-great-posts",
		title: "How to write great posts",
		author: "Editor",
		createdAt: new Date(Date.now() - 86400000 * 2),
		bannerImage:
			"https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=60",
		excerpt:
			"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas.",
	},
	{
		id: "sample-3",
		slug: "newsletter-setup-in-minutes",
		title: "Newsletter setup in minutes",
		author: "Editor",
		createdAt: new Date(Date.now() - 86400000 * 6),
		bannerImage:
			"https://images.unsplash.com/photo-1557200134-90327ee9fafa?auto=format&fit=crop&w=1200&q=60",
		excerpt:
			"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.",
	},
];

const formatDate = (date) => {
	if (!date) return "N/A";
	const d = date?.toDate ? date.toDate() : new Date(date);
	return d.toLocaleDateString("en-US", {
		year: "numeric",
		month: "short",
		day: "numeric",
	});
};

const HomePage = () => {
	const { data: blogs = [], isLoading } = useQuery({
		queryKey: ["blogs", "published"],
		queryFn: () => getAllBlogs("published"),
	});

	const posts = useMemo(() => {
		if (blogs?.length) return blogs;
		return SAMPLE_POSTS;
	}, [blogs]);

	return (
		<div className="min-h-screen flex flex-col">
				<Navbar />

			<section className="py-14 px-4 sm:px-6 lg:px-8 bg-white">
				<div className="max-w-6xl mx-auto">
					<div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
						<div className="lg:col-span-7">
							<h1 className="text-4xl sm:text-5xl font-bold text-zinc-900 leading-tight">
								A blog website builder kit — ready in minutes.
							</h1>
							<p className="mt-4 text-lg text-zinc-600 max-w-xl">
								Publish posts, collect newsletter subscribers, and track analytics
								with a clean admin CMS.
							</p>
							<div className="mt-7 flex flex-col sm:flex-row gap-3">
								<Link
									href="/blog"
									className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-zinc-900 text-white font-medium hover:bg-zinc-800 transition-colors"
								>
									Read the blog <ArrowRight className="w-4 h-4" />
									</Link>
									<Link
									href="/admin"
									className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-zinc-200 text-zinc-900 font-medium hover:border-zinc-300 hover:bg-zinc-50 transition-colors"
								>
									Open admin
								</Link>
							</div>
							<p className="mt-4 text-sm text-zinc-500">
								No posts yet? We render sample (lorem ipsum) posts automatically.
							</p>
						</div>

						<div className="lg:col-span-5">
							<SubscribeCard id="subscribe" />
						</div>
							</div>
						</div>
					</section>

			<section className="py-12 px-4 sm:px-6 lg:px-8 bg-zinc-50">
				<div className="max-w-6xl mx-auto">
					<div className="flex items-end justify-between gap-4 mb-6">
								<div>
							<h2 className="text-2xl font-bold text-zinc-900">Latest posts</h2>
							<p className="text-sm text-zinc-600">
								{isLoading ? "Loading…" : `${posts.length} posts`}
							</p>
											</div>
						<Link
							href="/blog"
							className="text-sm font-medium text-zinc-900 hover:text-zinc-600 transition-colors"
						>
							View all
						</Link>
								</div>

					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
						{posts.slice(0, 6).map((post, idx) => (
							<motion.article
								key={post.id || post.slug || idx}
								initial={{ opacity: 0, y: 14 }}
									whileInView={{ opacity: 1, y: 0 }}
								viewport={{ once: true, margin: "-80px" }}
								transition={{ duration: 0.5, ease: "easeOut", delay: idx * 0.05 }}
								className="flex flex-col bg-white border border-zinc-200 rounded-2xl overflow-hidden hover:shadow-md hover:border-zinc-300 transition-all"
							>
								{post.bannerImage && (
									<img
										src={post.bannerImage}
										alt={post.title}
										className="w-full h-44 object-cover"
									/>
								)}
								<div className="p-5 flex-1 flex flex-col">
									<div className="flex items-center gap-2 text-xs text-zinc-600">
										<Calendar className="w-3.5 h-3.5" />
										<span>{formatDate(post.createdAt)}</span>
										{post.author && (
											<>
												<span>•</span>
												<span>{post.author}</span>
											</>
										)}
									</div>
									<h3 className="mt-2 text-lg font-bold text-zinc-900">
										{post.title || "Untitled"}
									</h3>
									<p className="mt-2 text-sm text-zinc-600 leading-relaxed line-clamp-3">
										{post.excerpt ||
											"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."}
									</p>
									<div className="mt-4">
										<Link
											href={
												post.slug
													? `/blog/${post.slug}`
													: post.id
														? `/blog/id/${post.id}`
														: "/blog"
											}
											className="inline-flex items-center gap-2 text-sm font-medium text-zinc-900 hover:text-zinc-600 transition-colors"
										>
											Read more <ArrowRight className="w-4 h-4" />
										</Link>
									</div>
								</div>
							</motion.article>
						))}
					</div>
						</div>
					</section>

				<Footer />
			</div>
	);
};

export default HomePage;

