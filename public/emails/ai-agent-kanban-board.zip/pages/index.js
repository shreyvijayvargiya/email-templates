import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const AgentKanban = () => {
  const [agents, setAgents] = useState([
    {
      id: 'agent-1',
      name: 'Research Agent',
      avatar: '🔍',
      color: 'from-blue-500 to-cyan-500',
      status: 'active',
      tasks: [
        { id: 'task-1', title: 'Market Analysis Report', priority: 'high', status: 'in-progress' },
        { id: 'task-2', title: 'Competitor Research', priority: 'medium', status: 'todo' },
        { id: 'task-3', title: 'Customer Interviews', priority: 'low', status: 'todo' }
      ]
    },
    {
      id: 'agent-2',
      name: 'Content Agent',
      avatar: '✍️',
      color: 'from-purple-500 to-pink-500',
      status: 'active',
      tasks: [
        { id: 'task-4', title: 'Blog Post Draft', priority: 'high', status: 'in-progress' },
        { id: 'task-5', title: 'Social Media Content', priority: 'medium', status: 'todo' },
        { id: 'task-6', title: 'Email Newsletter', priority: 'high', status: 'todo' }
      ]
    },
    {
      id: 'agent-3',
      name: 'Code Agent',
      avatar: '💻',
      color: 'from-green-500 to-emerald-500',
      status: 'idle',
      tasks: [
        { id: 'task-7', title: 'API Integration', priority: 'high', status: 'in-progress' },
        { id: 'task-8', title: 'Bug Fixes', priority: 'medium', status: 'todo' }
      ]
    },
    {
      id: 'agent-4',
      name: 'Data Agent',
      avatar: '📊',
      color: 'from-orange-500 to-red-500',
      status: 'active',
      tasks: [
        { id: 'task-9', title: 'Data Pipeline Setup', priority: 'high', status: 'in-progress' },
        { id: 'task-10', title: 'Analytics Dashboard', priority: 'medium', status: 'todo' },
        { id: 'task-11', title: 'Database Optimization', priority: 'low', status: 'todo' }
      ]
    }
  ]);

  const [draggedTask, setDraggedTask] = useState(null);
  const [draggedFrom, setDraggedFrom] = useState(null);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'idle': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const handleDragStart = (task, agentId) => {
    setDraggedTask(task);
    setDraggedFrom(agentId);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (targetAgentId) => {
    if (!draggedTask || !draggedFrom) return;

    if (draggedFrom === targetAgentId) {
      setDraggedTask(null);
      setDraggedFrom(null);
      return;
    }

    setAgents(prevAgents => {
      const newAgents = [...prevAgents];
      
      // Remove task from source agent
      const sourceAgent = newAgents.find(a => a.id === draggedFrom);
      sourceAgent.tasks = sourceAgent.tasks.filter(t => t.id !== draggedTask.id);
      
      // Add task to target agent
      const targetAgent = newAgents.find(a => a.id === targetAgentId);
      targetAgent.tasks.push(draggedTask);
      
      return newAgents;
    });

    setDraggedTask(null);
    setDraggedFrom(null);
  };

  const toggleTaskStatus = (agentId, taskId) => {
    setAgents(prevAgents => {
      const newAgents = [...prevAgents];
      const agent = newAgents.find(a => a.id === agentId);
      const task = agent.tasks.find(t => t.id === taskId);
      task.status = task.status === 'todo' ? 'in-progress' : 'todo';
      return newAgents;
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">AI Agent Kanban</h1>
          <p className="text-slate-400">Organize tasks by agent, not by status</p>
        </motion.div>

        {/* Stats Bar */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-4 gap-4 mb-8"
        >
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 border border-slate-700">
            <div className="text-slate-400 text-sm">Total Agents</div>
            <div className="text-2xl font-bold text-white">{agents.length}</div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 border border-slate-700">
            <div className="text-slate-400 text-sm">Active Tasks</div>
            <div className="text-2xl font-bold text-white">
              {agents.reduce((sum, agent) => sum + agent.tasks.filter(t => t.status === 'in-progress').length, 0)}
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 border border-slate-700">
            <div className="text-slate-400 text-sm">Pending Tasks</div>
            <div className="text-2xl font-bold text-white">
              {agents.reduce((sum, agent) => sum + agent.tasks.filter(t => t.status === 'todo').length, 0)}
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-lg p-4 border border-slate-700">
            <div className="text-slate-400 text-sm">Active Agents</div>
            <div className="text-2xl font-bold text-white">
              {agents.filter(a => a.status === 'active').length}
            </div>
          </div>
        </motion.div>

        {/* Kanban Board */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {agents.map((agent, index) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(agent.id)}
              className="flex flex-col"
            >
              {/* Agent Header */}
              <div className={`bg-gradient-to-r ${agent.color} rounded-t-xl p-4 shadow-lg`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{agent.avatar}</span>
                    <div>
                      <h3 className="text-white font-bold text-lg">{agent.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`}></div>
                        <span className="text-white/80 text-xs capitalize">{agent.status}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-white/90 text-sm font-medium">
                  {agent.tasks.length} {agent.tasks.length === 1 ? 'task' : 'tasks'}
                </div>
              </div>

              {/* Tasks Container */}
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-b-xl p-4 border border-slate-700 border-t-0 flex-1 min-h-[400px]">
                <AnimatePresence>
                  {agent.tasks.map((task, taskIndex) => (
                    <motion.div
                      key={task.id}
                      layout
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.2 }}
                      draggable
                      onDragStart={() => handleDragStart(task, agent.id)}
                      className={`bg-slate-900/80 rounded-lg p-4 mb-3 cursor-move hover:shadow-lg transition-all border border-slate-700 hover:border-slate-600 ${
                        draggedTask?.id === task.id ? 'opacity-50' : ''
                      }`}
                    >
                      {/* Task Header */}
                      <div className="flex items-start justify-between mb-3">
                        <span className={`px-2 py-1 rounded text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                          {task.priority}
                        </span>
                        <button
                          onClick={() => toggleTaskStatus(agent.id, task.id)}
                          className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                            task.status === 'in-progress'
                              ? 'bg-blue-500 border-blue-500'
                              : 'border-slate-600 hover:border-slate-500'
                          }`}
                        >
                          {task.status === 'in-progress' && (
                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </button>
                      </div>

                      {/* Task Title */}
                      <h4 className="text-white font-medium mb-2 leading-snug">{task.title}</h4>

                      {/* Task Status Badge */}
                      <div className="flex items-center gap-2">
                        <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                          task.status === 'in-progress'
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-slate-700/50 text-slate-400'
                        }`}>
                          {task.status === 'in-progress' ? (
                            <>
                              <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                                className="w-3 h-3"
                              >
                                ⚙️
                              </motion.div>
                              <span>In Progress</span>
                            </>
                          ) : (
                            <>
                              <span>📋</span>
                              <span>To Do</span>
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {/* Empty State */}
                {agent.tasks.length === 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-full text-slate-500 py-8"
                  >
                    <div className="text-4xl mb-2">📭</div>
                    <div className="text-sm">No tasks assigned</div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Footer Tip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center text-slate-500 text-sm"
        >
          💡 Drag tasks between agents to reassign them
        </motion.div>
      </div>
    </div>
  );
};

export default AgentKanban;